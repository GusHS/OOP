/**
 * Calculadora
 */
public class Calculadora {

    // Programa de calculadora 
    public static void main(String[] args) {
        int a =1+1;
        int b; 
        System.out.println(a);
    }
}
